<?php

ini_set('error_reporting', E_ALL ^ E_NOTICE);
define(RUTA, __DIR__ . DIRECTORY_SEPARATOR);
define(FICHERO, __DIR__ . DIRECTORY_SEPARATOR . 'crey.xml');

class crey {

    private $dom, $xpath;
    private $inicio, $fin;
    private $horas;

    function __construct() {
        $this->dom = new DOMDocument('1.0', 'utf-8');
        $this->inicio = new DateTime('2017/06/01');
        $this->fin = new DateTime('2017/12/31');
        $this->horas = array("0" => [new DateTime('10:00'), new DateTime('17:00'), 180],
            "2" => [new DateTime('11:00'), new DateTime('16:00'), 150],
            "3" => [new DateTime('11:00'), new DateTime('16:00'), 150],
            "4" => [new DateTime('11:00'), new DateTime('16:00'), 150],
            "5" => [new DateTime('11:00'), new DateTime('16:00'), 150],
            "6" => [new DateTime('10:00'), new DateTime('17:00'), 180]);
    }

    public function genXML() {
        $str = "<entradas>";
        $period = new DatePeriod($this->inicio, DateInterval::createFromDateString('1 day'), $this->fin);
        foreach ($period as $dt) {
            $diaSemana = $dt->format("w");
            if ($diaSemana != "1") {
                $str .= "<entrada fecha='" . $dt->format("Ymd") . "'>";
                $periodH = new DatePeriod($this->horas[$diaSemana][0], DateInterval::createFromDateString('1 hour'), $this->horas[$diaSemana][1]);
                foreach ($periodH as $dtH) {
                    $str .= "<horario hora='" . $dtH->format("Hi") . "' plazas='" . $this->horas[$diaSemana][2] . "'/>";
                }
                $str .= "</entrada>";
            }
        }
        $str .= "</entradas>";
        $this->dom->loadXML($str);
        $this->dom->save(FICHERO);
    }

    public function readXML() {
        $fechaMax = 0;
        $fechaMin = 0;
        $this->dom->load(FICHERO);
        $xpath = new DOMXPath($this->dom);
        $aEntradas = [];
        $i = 0; //para acumular fechas
        foreach ($xpath->query("//entrada") as $date) {
            $aEntradas[$i]['fecha'] = $date->getAttribute("fecha");
            if ($i == 0) {
                $fechaMax = $date->getAttribute("fecha");
                $fechaMin = $date->getAttribute("fecha");
            } else {
                $fechaMax = (int) $this->buscaFechaMayor($fechaMax, $date->getAttribute("fecha"));
                $fechaMin = (int) $this->buscaFechaMenor($fechaMin, $date->getAttribute("fecha"));
            }
            foreach ($date->childNodes as $horario) {
                $aEntradas[$i]['horario'][] = array(
                    'hora' => $horario->getAttribute("hora"),
                    'entradas' => $horario->nodeValue
                );
            }
            $i++;
        }
        echo json_encode(array("entradas" => $aEntradas, "fechaMax" => $fechaMax, "fechaMin" => $fechaMin));
    }

    public function buscaFechaMayor($fecha1, $fecha2) {
        return ((int) $fecha1 > (int) $fecha2 ) ? $fecha1 : $fecha2;
    }

    public function buscaFechaMenor($fecha1, $fecha2) {
        return ((int) $fecha1 < (int) $fecha2 ) ? $fecha1 : $fecha2;
    }

    public function getDispo($idAgencia, $fecha, $hora, $entradas) {
        if (!(file_exists(FICHERO))) {
            $result = ["status" => "ko", "mensaje" => "El archivo no existe!."];
        } else {
            $this->dom->load(FICHERO);
            $this->xpath = new DOMXPath($this->dom);
            if ($result = $this->xpath->query("//entrada[@fecha='$fecha']/horario[@hora='$hora']")) {
                if (empty($result)) {
                    $result = ["status" => "ko", "mensaje" => "En el día indicado no existen entradas disponibles (lunes)"];
                } else {
                    echo $result->item(0)->getAttribute('plazas').PHP_EOL;
                }
                //if ((int) $result->item(0)->nodeValue > (int) $entradas) {
                //$reserva = $dom->createElement('reserva');
                //$result->item(0)->appendChild($reserva);
                //$reserva->setAttribute("idAgencia", $idAgencia);
                //$reserva->setAttribute("entradas", $entradas);
                //$hoy = getdate();
                //$horaActual = $hoy[year] . $hoy[mon] . $hoy[mday] . $hoy[hours] . $hoy[minutes] + 10;
                //$reserva->setAttribute("tiempo", $horaActual);
                //$dom->save(RUTA . 'crey.xml');
                //$resultado = ["status" => "ok", "mensaje" => "Correcto! La reserva se realizo correctamente!."];
                //} else {
                //$resultado = ["status" => "ko", "mensaje" => "Error! solo hay disponible " . $result->item(0)->nodeValue . " entradas"];
                //}
            }
        }


        //Si es ko, los mensajes oportunos...
        //Si es ok, tengo que añadir al nodo xml
        //<reserva idAgencia="520" entradas="30" tiempo="20170406133815"/>	
        //donde el tiempo es 10 minutos más de ahora
        //el xml hay que guardarlo
        //contemplar la dispo es 180 - 30 - 12
        return json_encode($result);
    }

}
