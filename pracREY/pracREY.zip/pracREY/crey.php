<?php

ini_set('error_reporting', E_ALL ^ E_NOTICE);
define(RUTA, __DIR__ . DIRECTORY_SEPARATOR);

$idAgencia='520';

require_once RUTA . 'crey.class.php';

$cr = new crey();

//$cr->genXML();

//echo $cr->getDispo($idAgencia,'20170611','1200','25');



//$result  {"status":"ok","mensaje":"Hay entradas disponibles","tiempo":"12:28:15"}
//$result  {"status":"ko","mensaje":"No hay entradas" | "Día no disponible" | " Solo hay disponibles x entradas en este día"}
