#!bin/bash

while [ 1 ]
do
php crey.php 'accion=review'
sleep 60
done
 /*http://stackoverflow.com/questions/5655284/how-to-pass-parameters-from-command-line-to-post-in-php-script*/