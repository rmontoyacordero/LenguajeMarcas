<?php

ini_set('error_reporting', E_ALL ^ E_NOTICE);
define(RUTA, __DIR__ . DIRECTORY_SEPARATOR);

require_once RUTA . 'crey.class.php';

$cr = new crey();
$accion = filter_input(INPUT_POST, 'check');
$idAgencia = filter_input(INPUT_POST, 'idAgencia');
$fecha = filter_input(INPUT_POST, 'date');
$hora = filter_input(INPUT_POST, 'hour');
$tickets = filter_input(INPUT_POST, 'tickets');

if ($accion == "inicio") {
    echo $cr->getDates();
}
if ($accion == "reserve") {
    echo $cr->getDispo($idAgencia, $fecha, $hora, $tickets);
}
if ($accion == "review") {
    echo $cr->reviewReservation();
}